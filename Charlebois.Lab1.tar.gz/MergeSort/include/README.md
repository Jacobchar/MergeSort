# MergeSort
Assignment 1 for CMPT 379

Mergesort algorithm that implements the use of fork() in C.
